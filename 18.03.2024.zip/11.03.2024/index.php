<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style> 
        .no-show{
            display: none;
        }
    </style>
</head>
<body>
    
<?php 
//Przetestuj działanie skryptów PHP umieszczonych w powyższym pliku pdf.
setcookie('nick', 'Kasia', time()+10);
echo "Masz na imie ".$_COOKIE['nick'];
echo "<br/>";
setcookie('nickenc', base64_encode("Martin"), time()+10);
echo "Masz na imie ".base64_decode($_COOKIE['nickenc']);
echo "<br/>";

setcookie('wizyta', time(), time()+30*86400);
if(!isset($_COOKIE['wizyta'])){
    echo "Witaj";
} else {
    echo "Ostatnia wizyta ".date('d.m.Y, H:i', $_COOKIE['wizyta']);
}

?>
<h2>Zadanie 2</h2>
<?php 
setcookie('powraca', true, time()+10);
if(!isset($_COOKIE['powraca'])){
    echo "Pierwszy raz na stronie, Witamy";
} else { 
    echo "Byłeś już tutaj, Witamy ponownie";
}

?>
<h2>Zadanie 3</h2>
<form action="index.php" method="POST">
    <input type="date" name="birthdate" required>
    <button type="submit" name="submit">Submit </button>
</form>
<?php 

if(isset($_COOKIE['zadanie3a'])){
    echo "zaraz po";
} else { 
    setcookie('zadanie3a', time(), time()+60);
}

if(isset($_POST['submit']) && $_POST['birthdate']){
    setcookie('birthdate',$_POST['birthdate'], time()+60*60*24*100);
}


function DaysUntilBday($birthdate){
        $currDate = date('Y-m-d');

        //object 
        $birthdateObj =  new DateTime($birthdate);
        $currentDateObj = new DateTime($currDate);
    
        $birthdateObj->setDate($currentDateObj->format('Y'), $birthdateObj->format('m'),  $birthdateObj->format('d'));
    
        if($birthdateObj < $currentDateObj){
            $birthdateObj->modify("+1 year");
        }
    
        $int = $currentDateObj->diff($birthdateObj);
    
        echo "Twoje urodziny są za: ".$int->days.(($int->days === 1 )? " dzień" : " dni");
}
if(isset($_COOKIE["birthdate"])){
    daysUntilBday($_COOKIE["birthdate"]);
}
?>

<h2>Zadanie 4</h2>
<?php if(isset($_COOKIE['form4'])){ echo "<div class='no-show'>";} ?>
<form ction="index.php" method="POST">
    <input type="text" name="imie" require>
    <input type="date" name="bday" require>
    <button type="submit" name="submit2">Submit </button>
</form>
<?php if(isset($_COOKIE['form4'])){ echo "</div>";} ?>


<?php 
    if(isset($_COOKIE['form4']) && $_COOKIE['wiek'] >= 13){ 
        echo "<h2>Witaj ".$_COOKIE["name"]." Wiek:  ".$_COOKIE['wiek'];
    } elseif (isset($_COOKIE['form4']) && $_COOKIE['wiek'] < 13){ 
        echo "<h2>".$_COOKIE["name"]." nie masz ukończonych 13 lat </h2>";
    }
?>


<?php 
if(isset($_POST['submit2'])){
    setcookie('form4', true, time()+60*60*24*30);
    setcookie('name', $_POST['imie'], time()+60*60*24*30);
    $t = new DateTime();
    $bday = new DateTime($_POST['bday']);
    $int = $t->diff($bday);
    setcookie('wiek', $int->y, time()+60*60*24*30);
}

?>
<h2>Zadanie 5</h2>
<?php if(isset($_COOKIE['form5'])){  echo "<div class='no-show'>";} ?>
<form action="index.php" method="POST">
  <label for="num">Wiek:</label><br>
    <input type="number" name="num" required><br>

  <label for="text">Imie:</label><br>
    <input type="text" name="text" required><br>

  <label for="list">Status:</label><br>
  <select name="list" required>
    <option value="Uczeń">Uczeń</option>
    <option value="Bezrobotny">Bezrobotny</option>
    <option value="Pracujący">Pracujący</option>
  </select><br>

  <input type="checkbox" name="check" value="cbx">
  <label for="check">Obywatelstwo Polskie</label><br>

  <span>Prawo jazdy</span><br>
  <input type="radio"  name="radio" value="Tak" required>
  <label for="radio1">Tak</label><br>
  <input type="radio"  name="radio" value="Nie" required>
  <label for="radio2">Nie</label><br>


  <input type="range" name="slide" min="1" max="10" require>
  <label for="slide">Jak oceniasz naszą firme</label><br>
  <input type="submit" value="submit" name="submit3">

</form>
<?php if(isset($_COOKIE['form5'])){ echo "</div>";} ?>
<?php if(isset($_COOKIE['form5'])){
    echo "Wiek: ".$_COOKIE['wiek5']."<br>";
    echo "Imie: ".$_COOKIE['imie5']."<br>";
    echo "Status: ".$_COOKIE['status']."<br>";
    echo "Polskie Obywatelstwo: ".$_COOKIE['obywatelstwo']."<br>";
    echo "Prawo Jazdy: ".$_COOKIE['prawko']."<br>";
    echo "Ocena: ".$_COOKIE['ocena']."<br>";


}
?>


<?php
 if(isset($_POST['submit3'])){
    setcookie('form5', true, time()+60*60*24*1);
    $w = $_POST['num'];
    $fn = $_POST['text'];
    $s = $_POST['list'];
    if(isset($_POST['check'])){
        $chk = "tak";
    } else { 
        $chk = "nie";
    }
    $r = $_POST['radio'];
    $sl = $_POST['slide'];

    setcookie('wiek5', $w, time()+60*60*24);
    setcookie('imie5', $fn, time()+60*60*24);
    setcookie('status', $s, time()+60*60*24);
    setcookie('obywatelstwo', $chk, time()+60*60*24);
    setcookie('prawko', $r, time()+60*60*24);
    setcookie('ocena', $sl, time()+60*60*24);
    setcookie('form5', true, time()+60*60*24);


 }
?>

</body>
</html>