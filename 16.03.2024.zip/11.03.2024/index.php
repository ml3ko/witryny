<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style> 
        .no-show{
            display: none;
        }
    </style>
</head>
<body>
    
<?php 
//Przetestuj działanie skryptów PHP umieszczonych w powyższym pliku pdf.
setcookie('nick', 'Kasia', time()+10);
echo "Masz na imie ".$_COOKIE['nick'];
echo "<br/>";
setcookie('nickenc', base64_encode("Martin"), time()+10);
echo "Masz na imie ".base64_decode($_COOKIE['nickenc']);
echo "<br/>";

setcookie('wizyta', time(), time()+30*86400);
if(!isset($_COOKIE['wizyta'])){
    echo "Witaj";
} else {
    echo "Ostatnia wizyta ".date('d.m.Y, H:i', $_COOKIE['wizyta']);
}

?>
<h2>Zadanie 2</h2>
<?php 
setcookie('powraca', true, time()+10);
if(!isset($_COOKIE['powraca'])){
    echo "Pierwszy raz na stronie, Witamy";
} else { 
    echo "Byłeś już tutaj, Witamy ponownie";
}

?>
<h2>Zadanie 3</h2>
<form action="index.php" method="POST">
    <input type="date" name="birthdate">
    <button type="submit" name="submit">Submit </button>
</form>
<?php 

if(isset($_COOKIE['zadanie3a'])){
    echo "zaraz po";
} else { 
    setcookie('zadanie3a', time(), time()+60);
}

if(isset($_POST['submit']) && $_POST['birthdate']){
    setcookie('birthdate',$_POST['birthdate'], time()+60*60*24*100);
}


function DaysUntilBday($birthdate){
        $currDate = date('Y-m-d');

        //object 
        $birthdateObj =  new DateTime($birthdate);
        $currentDateObj = new DateTime($currDate);
    
        $birthdateObj->setDate($currentDateObj->format('Y'), $birthdateObj->format('m'),  $birthdateObj->format('d'));
    
        if($birthdateObj < $currentDateObj){
            $birthdateObj->modify("+1 year");
        }
    
        $int = $currentDateObj->diff($birthdateObj);
    
        echo "Twoje urodziny są za: ".$int->days.(($int->days === 1 )? " dzień" : " dni");
}
if(isset($_COOKIE["birthdate"])){
    daysUntilBday($_COOKIE["birthdate"]);
}
?>

<h2>Zadanie 4</h2>
<?php if(isset($_COOKIE['form4'])){ echo "<div class='no-show'>";} ?>
<form ction="index.php" method="POST">
    <input type="text" name="imie" require>
    <input type="date" name="bday" require>
    <button type="submit" name="submit2">Submit </button>
</form>
<?php if(isset($_COOKIE['form4'])){ echo "</div>";} ?>


<?php 
    if(isset($_COOKIE['form4']) && $_COOKIE['wiek'] >= 13){ 
        echo "<h2>Witaj ".$_COOKIE["name"]." Lat ".$_COOKIE['wiek'];
    } elseif (isset($_COOKIE['form4']) && $_COOKIE['wiek'] < 13){ 
        echo "<h2>".$_COOKIE["name"]." nie masz ukończonych 13 lat </h2>";
    }
?>


<?php 
if(isset($_POST['submit2'])){
    setcookie('form4', true, time()+60*60*24*30);
    setcookie('name', $_POST['imie'], time()+60*60*24*30);
    $t = new DateTime();
    $bday = new DateTime($_POST['bday']);

    $int = $t->diff($bday);



    setcookie('wiek', $int->y, time()+60*60*24*30);
}

?>





</body>
</html>