
<?php
$user = 'root';
$pass = '';
try {
    $dbh = new PDO('mysql:host=localhost;dbname=personalia', $user, $pass);
} catch (PDOException $e) {
    // attempt to retry the connection after some timeout for example
}

$stmt = $dbh->prepare("SELECT * FROM dane where zawod = :zawod ");
$stmt->execute([':zawod' => 'informatyk']);
$arr = $stmt->fetchAll(PDO::FETCH_ASSOC);
if(!$arr) exit('No rows');




// Fetch Zawody
$stmt2 = $dbh->prepare("SELECT DISTINCT zawod FROM dane");
$stmt2->execute();
$zawody = $stmt2->fetchAll(PDO::FETCH_ASSOC);

//fetch wszystkie dane 
if(isset($_POST['zawod'])){
    $stmt3 = $dbh->prepare("SELECT * FROM osoby INNER JOIN dane ON osoby.Id_osoby = dane.Id_osoby WHERE zawod = :zawod");
    $stmt3->execute([':zawod' => $_POST['zawod']]);
    $data = $stmt3->fetchAll(PDO::FETCH_ASSOC);
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./style.css">
    <title>Document</title>
</head>
<body>
    <form action="index.php" method="POST"> 
        <select name="zawod">
            <?php 
                foreach ($zawody as $zawod) {
                echo "<option value='".$zawod['zawod']."'>".$zawod['zawod']."</option>";
                }
            ?>
        </select>
    <button type="submit">Wyszukaj osoby</button>


    <table>
        <tr>
            <th>Imie</th>
            <th>Nazwisko</th>
            <th>pesel</th>
            <th>Data Urodzenia</th>
            <th>zawod</th>
            <th>Zdjecie</th>
        </tr>
        <?php 
        if(isset($data)){
        foreach($data as $key => $p){
            echo "<tr>";
            echo "<td>" . $p['imie'] . "</td>";
            echo "<td>" . $p['nazwisko'] . "</td>";
            echo "<td>" . $p['pesel'] . "</td>";
            echo "<td>" . $p['data_ur'] . "</td>";
            echo "<td>" . $p['zawod'] . "</td>";
            echo "<td> <img src='./img/" . $p['zdjecie'] . "'></td>";
            echo "</tr>";
        }
    }
        ?>
    </table>
    <?php
    if(isset($data)){
    $currentDate = date('Y-m-d'); 
    $month = date('m', strtotime($currentDate));
    $day = date('d', strtotime($currentDate));
    $file = fopen("wynik.txt", "w");
    echo "<textarea>";
        foreach($data as $p){
            $Bmonth = date('m', strtotime($p['data_ur']));
            $Bday = date('d', strtotime($p['data_ur']));

            if($day === $Bday && $month === $Bmonth){
                
                echo $p['imie'].' '.$p['nazwisko'].' '.$p['data_ur'].' Ma dziś urodziny.&#13;&#10;';
                fwrite($file, $p['imie'] . ' ' . $p['nazwisko'] . ', ' . $p['data_ur'] . PHP_EOL);
            }
        }
        echo "</textarea>";
        fclose($file);
        $content = file_get_contents('./wynik.txt', true);
        $lines = explode("\n", $content);
        $lines = array_slice($lines, 0, -1);
    echo "<br>";
    echo "<ol type='I'>";
    foreach ($lines as $line) {
        echo "<li>".$line."</li>";
    }
    echo "</ol>";
}
    ?>

</body>
</html>