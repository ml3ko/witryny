-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2024 at 01:41 PM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `personalia`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `dane`
--

CREATE TABLE `dane` (
  `Id_osoby` int(10) UNSIGNED NOT NULL UNIQUE,
  `data_ur` date NOT NULL,
  `zawod` varchar(128) NOT NULL,
  `zdjecie` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dane`
--

INSERT INTO `dane` (`Id_osoby`, `data_ur`, `zawod`, `zdjecie`) VALUES
(1, '1997-04-02', 'Informatyk', 'Black.png'),
(2, '2002-04-10', 'Informatyk', 'Red.png'),
(3, '1996-04-03', 'Elektryk', 'Red.png'),
(4, '1999-04-01', 'Kucharz', 'Blue.png'),
(5, '1979-04-01', 'Nauczyciel', 'Green.png');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `osoby`
--

CREATE TABLE `osoby` (
  `Id_osoby` int(10) UNSIGNED NOT NULL,
  `imie` varchar(32) NOT NULL,
  `nazwisko` varchar(64) NOT NULL,
  `pesel` char(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `osoby`
--

INSERT INTO `osoby` (`Id_osoby`, `imie`, `nazwisko`, `pesel`) VALUES
(1, 'Jan', 'Kowalski', '12312312312'),
(2, 'Andrzej', 'Inda', '32132132121'),
(3, 'Marek', 'Markowski', '98765432112'),
(4, 'Amir', 'Turkowski', '56748392101'),
(5, 'Adam', 'Abacki', '09876543216');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `dane`
--
ALTER TABLE `dane`
  ADD KEY `FK_PersonOrder` (`Id_osoby`);

--
-- Indeksy dla tabeli `osoby`
--
ALTER TABLE `osoby`
  ADD PRIMARY KEY (`Id_osoby`),
  ADD UNIQUE KEY `pesel` (`pesel`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `osoby`
--
ALTER TABLE `osoby`
  MODIFY `Id_osoby` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dane`
--
ALTER TABLE `dane`
  ADD CONSTRAINT `FK_PersonOrder` FOREIGN KEY (`Id_osoby`) REFERENCES `osoby` (`Id_osoby`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
